def detect_document_type(digits):
    """
    Determine if the document is a CPF or CNPJ based on the number of digits.
    
    Args:
        digits (str): Document digits (numbers only)
    
    Returns:
        str: 'CPF', 'CNPJ', or None if the length doesn't match either
    """
    if len(digits) == 11:
        return 'CPF'
    elif len(digits) == 14:
        return 'CNPJ'
    return None


def format_cpf_cnpj(value):
    """
    Recebe um número ou string e formata como CPF ou CNPJ.
    
    CPF: 11 dígitos -> xxx.xxx.xxx-xx 
    CNPJ: 14 dígitos -> xx.xxx.xxx/xxxx-xx
    
    Args:
        value (str): CPF ou CNPJ (com ou sem formatação)
    
    Returns:
        str: CPF ou CNPJ formatado, ou None se inválido
    """
    # Remove quaisquer caracteres que não sejam dígitos
    digits = ''.join(filter(str.isdigit, str(value)))
    
    if len(digits) == 11:
        # Formatação para CPF
        formatted = f"{digits[:3]}.{digits[3:6]}.{digits[6:9]}-{digits[9:]}"
        return formatted
    elif len(digits) == 14:
        # Formatação para CNPJ
        formatted = f"{digits[:2]}.{digits[2:5]}.{digits[5:8]}/{digits[8:12]}-{digits[12:]}"
        return formatted
    else:
        return None


def validate_cpf(cpf_digits):
    """
    Valida um CPF (apenas dígitos).
    
    Args:
        cpf_digits (str): CPF (11 dígitos, apenas números)
    
    Returns:
        bool: True se válido, False se inválido
    """
    # Verifica requisitos básicos
    if not cpf_digits or not cpf_digits.isdigit() or len(cpf_digits) != 11:
        return False
    
    # Verifica se todos os dígitos são iguais (CPF inválido)
    if len(set(cpf_digits)) == 1:
        return False
    
    # Validação do primeiro dígito verificador
    sum_products = 0
    for i in range(9):
        sum_products += int(cpf_digits[i]) * (10 - i)
    
    remainder = sum_products % 11
    digit1 = 0 if remainder < 2 else 11 - remainder
    
    if digit1 != int(cpf_digits[9]):
        return False
    
    # Validação do segundo dígito verificador
    sum_products = 0
    for i in range(10):
        sum_products += int(cpf_digits[i]) * (11 - i)
    
    remainder = sum_products % 11
    digit2 = 0 if remainder < 2 else 11 - remainder
    
    if digit2 != int(cpf_digits[10]):
        return False
    
    return True


def validate_cnpj(cnpj_digits):
    """
    Valida um CNPJ (apenas dígitos).
    
    Args:
        cnpj_digits (str): CNPJ (14 dígitos, apenas números)
    
    Returns:
        bool: True se válido, False se inválido
    """
    # Verifica requisitos básicos
    if not cnpj_digits or not cnpj_digits.isdigit() or len(cnpj_digits) != 14:
        return False
    
    # Verifica se todos os dígitos são iguais (CNPJ inválido)
    if len(set(cnpj_digits)) == 1:
        return False
    
    # Validação do primeiro dígito verificador
    weights = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    sum_products = 0
    
    for i in range(12):
        sum_products += int(cnpj_digits[i]) * weights[i]
    
    remainder = sum_products % 11
    digit1 = 0 if remainder < 2 else 11 - remainder
    
    if digit1 != int(cnpj_digits[12]):
        return False
    
    # Validação do segundo dígito verificador
    weights = [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    sum_products = 0
    
    for i in range(13):
        sum_products += int(cnpj_digits[i]) * weights[i]
    
    remainder = sum_products % 11
    digit2 = 0 if remainder < 2 else 11 - remainder
    
    if digit2 != int(cnpj_digits[13]):
        return False
    
    return True


def validate_and_format_cpf(cpf_digits):
    """
    Validate and format a CPF number.
    
    Args:
        cpf_digits (str): CPF digits (11 digits, numbers only)
    
    Returns:
        tuple: (is_valid, formatted_cpf)
    """
    is_valid = validate_cpf(cpf_digits)
    formatted = format_cpf_cnpj(cpf_digits) if is_valid else None
    
    return is_valid, formatted


def validate_and_format_cnpj(cnpj_digits):
    """
    Validate and format a CNPJ number.
    
    Args:
        cnpj_digits (str): CNPJ digits (14 digits, numbers only)
    
    Returns:
        tuple: (is_valid, formatted_cnpj)
    """
    is_valid = validate_cnpj(cnpj_digits)
    formatted = format_cpf_cnpj(cnpj_digits) if is_valid else None
    
    return is_valid, formatted
