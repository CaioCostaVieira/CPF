document.addEventListener('DOMContentLoaded', function() {
    const documentForm = document.getElementById('document-form');
    const documentInput = document.getElementById('document');
    const resultContainer = document.getElementById('result-container');
    const resultHeader = document.getElementById('result-header');
    const resultIcon = document.getElementById('result-icon');
    const resultMessage = document.getElementById('result-message');
    const formattedContainer = document.getElementById('formatted-container');
    const formattedDocument = document.getElementById('formatted-document');
    const docTypeValue = document.getElementById('doc-type-value');
    const clearBtn = document.getElementById('clear-btn');
    const copyBtn = document.getElementById('copy-btn');
    const formatOnlyCheckbox = document.getElementById('format-only');
    const buttonText = document.getElementById('button-text');
    
    // Form submission handler
    documentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Check if "format only" mode is enabled
        if (formatOnlyCheckbox && formatOnlyCheckbox.checked) {
            formatDocumentOnly();
        } else {
            validateDocument();
        }
    });
    
    // Update button text when format-only checkbox is toggled
    if (formatOnlyCheckbox) {
        formatOnlyCheckbox.addEventListener('change', function() {
            buttonText.textContent = this.checked ? 'Formatar' : 'Validar';
        });
    }
    
    // Clear button handler
    clearBtn.addEventListener('click', function() {
        documentInput.value = '';
        resultContainer.classList.add('d-none');
        documentInput.focus();
    });
    
    // Copy button handler
    copyBtn.addEventListener('click', function() {
        formattedDocument.select();
        document.execCommand('copy');
        
        // Change button icon temporarily to indicate success
        const originalHTML = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="fas fa-check"></i>';
        copyBtn.classList.add('btn-success');
        copyBtn.classList.remove('btn-outline-secondary');
        
        setTimeout(() => {
            copyBtn.innerHTML = originalHTML;
            copyBtn.classList.remove('btn-success');
            copyBtn.classList.add('btn-outline-secondary');
        }, 1500);
    });
    
    // Input mask for better UX (simple version)
    documentInput.addEventListener('input', function() {
        const value = this.value.replace(/\D/g, '');
        
        if (value.length <= 11) {
            // CPF formatting
            this.value = formatCPF(value);
        } else {
            // CNPJ formatting
            this.value = formatCNPJ(value);
        }
    });
    
    // Format input as CPF: XXX.XXX.XXX-XX
    function formatCPF(value) {
        return value
            .replace(/(\d{3})(\d)/, '$1.$2')
            .replace(/(\d{3})(\d)/, '$1.$2')
            .replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    }
    
    // Format input as CNPJ: XX.XXX.XXX/XXXX-XX
    function formatCNPJ(value) {
        return value
            .replace(/(\d{2})(\d)/, '$1.$2')
            .replace(/(\d{3})(\d)/, '$1.$2')
            .replace(/(\d{3})(\d)/, '$1/$2')
            .replace(/(\d{4})(\d{1,2})$/, '$1-$2');
    }
    
    // Function to format document without validation
    function formatDocumentOnly() {
        const document = documentInput.value;
        
        // Simple client-side validation before sending to server
        if (!document) {
            showError('Por favor, informe um CPF ou CNPJ.');
            return;
        }
        
        // Create form data for the request
        const formData = new FormData();
        formData.append('document', document);
        
        // Send request to server for formatting only
        fetch('/format', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.formatted) {
                showFormattedResult(data);
            } else {
                showError('O número informado não possui a quantidade correta de dígitos.');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Ocorreu um erro ao formatar o documento. Tente novamente.');
        });
    }
    
    // Function to validate document with the server
    function validateDocument() {
        const document = documentInput.value;
        
        // Simple client-side validation before sending to server
        if (!document) {
            showError('Por favor, informe um CPF ou CNPJ.');
            return;
        }
        
        // Create form data for the request
        const formData = new FormData();
        formData.append('document', document);
        
        // Send request to server for validation
        fetch('/validate', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            displayResult(data);
        })
        .catch(error => {
            console.error('Error:', error);
            showError('Ocorreu um erro ao validar o documento. Tente novamente.');
        });
    }
    
    // Função para automaticamente copiar texto para a área de transferência
    function copyToClipboard(text) {
        // Armazena o texto no campo de documento formatado
        formattedDocument.value = text;
        
        // Seleciona o texto
        formattedDocument.select();
        
        // Executa o comando de cópia
        const successful = document.execCommand('copy');
        
        // Mostra feedback visual temporário
        if (successful) {
            // Destaca o campo de texto brevemente
            formattedDocument.classList.add('bg-success', 'text-white');
            
            // Mostra mensagem de sucesso temporária
            const originalCopyBtnHTML = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="fas fa-check"></i>';
            copyBtn.classList.add('btn-success');
            copyBtn.classList.remove('btn-outline-secondary');
            
            // Restaura a aparência normal após um curto período
            setTimeout(() => {
                formattedDocument.classList.remove('bg-success', 'text-white');
                copyBtn.innerHTML = originalCopyBtnHTML;
                copyBtn.classList.remove('btn-success');
                copyBtn.classList.add('btn-outline-secondary');
            }, 1500);
        }
        
        // Remove a seleção do texto
        formattedDocument.blur();
        
        return successful;
    }
    
    // Display formatting result (no validation)
    function showFormattedResult(data) {
        resultContainer.classList.remove('d-none');
        
        // Format successful
        resultHeader.className = 'card-header bg-info text-white';
        resultIcon.className = 'fas fa-info-circle fs-1 text-info';
        resultMessage.textContent = `Documento formatado e copiado para a área de transferência`;
        
        // Show formatted document with copy button
        formattedContainer.classList.remove('d-none');
        formattedDocument.value = data.formatted;
        
        // Automatically copy to clipboard
        copyToClipboard(data.formatted);
        
        // Show document type
        docTypeValue.textContent = data.type || 'Desconhecido';
    }
    
    // Display validation result
    function displayResult(data) {
        resultContainer.classList.remove('d-none');
        
        if (data.valid) {
            // Valid document
            resultHeader.className = 'card-header bg-success text-white';
            resultIcon.className = 'fas fa-check-circle fs-1 text-success';
            resultMessage.textContent = data.message + " Copiado para a área de transferência.";
            
            // Show formatted document with copy button
            formattedContainer.classList.remove('d-none');
            formattedDocument.value = data.formatted;
            
            // Automatically copy to clipboard
            copyToClipboard(data.formatted);
            
            // Show document type
            docTypeValue.textContent = data.type;
        } else {
            // Invalid document
            resultHeader.className = 'card-header bg-danger text-white';
            resultIcon.className = 'fas fa-times-circle fs-1 text-danger';
            resultMessage.textContent = data.message;
            
            // Show formatted document if available
            if (data.formatted) {
                formattedContainer.classList.remove('d-none');
                formattedDocument.value = data.formatted;
                
                // Automatically copy to clipboard even for invalid but formattable documents
                copyToClipboard(data.formatted);
            } else {
                formattedContainer.classList.add('d-none');
            }
            
            // Show document type if provided
            docTypeValue.textContent = data.type || 'Desconhecido';
        }
    }
    
    // Show error message
    function showError(message) {
        resultContainer.classList.remove('d-none');
        resultHeader.className = 'card-header bg-danger text-white';
        resultIcon.className = 'fas fa-exclamation-circle fs-1 text-danger';
        resultMessage.textContent = message;
        formattedContainer.classList.add('d-none');
        docTypeValue.textContent = 'Erro';
    }
});
